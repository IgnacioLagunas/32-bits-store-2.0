export default {
  data: [
    { name: 'Casa', id: '0', price: 100.0},
    { name: 'Bote', id: '1', price: 100.0},
    { name: 'Avión', id: '2', price: 100.0},
    { name: 'Motocicleta', id: '3', price: 100.0},
    { name: 'Computadora', id: '4', price: 100.0},
    { name: 'Silla', id: '5', price: 100.0},
    { name: 'Espejo', id: '6', price: 100.0},
    { name: 'Mesa', id: '7', price: 100.0},
    { name: 'Café', id: '8', price: 100.0},
    { name: 'Bicicleta', id: '9', price: 100.0},
    { name: 'Gato', id: '10', price: 100.0},
    { name: 'Parlante', id: '11', price: 100.0},
    { name: 'Plancha', id: '12', price: 100.0},
    { name: 'Libro', id: '13', price: 100.0},
  ]
}
